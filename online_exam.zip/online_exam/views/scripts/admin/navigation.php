<style>
a{
  text-decoration: none;
  font-family: 'Lucida Grande',Helvetica,Arial,Verdana,sans-serif; font-size: 0.9em; color: blue!important;
}
  a:hover {
  text-decoration: underline;
}
</style>
<table style="font-family: 'Lucida Grande',Helvetica,Arial,Verdana,sans-serif; font-size: 0.9em; color: #535353!important;
">
<tr>
	<td> <a href="javascript:loadPage('index.php?admin/users');"> Users </a> </td>
	<td> &nbsp; <a href="javascript:loadPage('index.php?admin/departments');"> Departments </a> </td>
	<td> &nbsp;<a href="javascript:loadPage('index.php?admin/exams');"> Examinations </a> </td>
	<td> &nbsp;<a href="javascript:loadPage('index.php?admin/examsresult');"> Examinations Results </a> </td>
	<td> &nbsp;<a href="index.php?authenticate/logout"> Logout </a> </td>
</tr>
</table><br />