<style>

.mcstyle{
		font-family: 'Lucida Grande',Helvetica,Arial,Verdana,sans-serif; font-size: 0.9em; color: #535353!important;
}
</style>
<div style="width: 100%;" class="mcstyle">
	<div style="width: 50%; align: center;">
		<b> Thank You For Taking The Exam </b>
	</br>
		<a href="index.php?staff/viewresults2&exam_id=<?php echo $_GET['exam_id'];?>"> View Results</a>
	</div>
</div>